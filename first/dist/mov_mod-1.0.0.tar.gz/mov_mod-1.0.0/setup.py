from distutils.core import setup

setup(
    name='mov_mod',
    version='1.0.0',
    py_modules=['mov_mod'],
    author='hfpython',
    author_email='cpujari12@gmail.com',
    description='a simple printer of nested lists'

)